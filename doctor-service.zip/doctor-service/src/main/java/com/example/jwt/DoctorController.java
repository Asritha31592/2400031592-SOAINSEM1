package com.example.jwt;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/doctors")
public class DoctorController {

    @GetMapping
    public List<Map<String, Object>> getDoctors() {
        return List.of(
            Map.of("id", 101, "name", "Dr. Sharma"),
            Map.of("id", 102, "name", "Dr. Reddy")
        );
    }
}